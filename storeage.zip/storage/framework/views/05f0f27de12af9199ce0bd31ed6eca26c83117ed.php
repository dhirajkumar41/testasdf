<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title> <?php echo $__env->yieldContent('page_title'); ?></title>
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo e(asset('public/website-assets/images/images/header_logo.gif')); ?>">
    <!---------------------------------- Css Files Link ---------------------------------->
    
    
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
    <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <link href="<?php echo e(asset('public/website-assets/css/bootstrap.min.css')); ?>" rel="stylesheet" id="bootstrap-css">
    
    <link href="<?php echo e(asset('public/website-assets/css/jquery-ui.min.css')); ?>" rel="stylesheet">
    
    
    

    <link href="<?php echo e(asset('public/website-assets/css/jquery.mCustomScrollbar.css')); ?>" rel="stylesheet">
    

    <link href="<?php echo e(asset('public/website-assets/css/animated.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/website-assets/css/owl.carousel.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('public/website-assets/css/owl.theme.css')); ?>" rel="stylesheet" type="text/css" />
    
    <link href="<?php echo e(asset('public/website-assets/css/animated.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('public/website-assets/css/main.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('public/website-assets/css/responsive.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('public/website-assets/css/all.css')); ?>" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('public/website-assets/css/learn-to-fly.css')); ?>" type="text/css"/>
    <script src="<?php echo e(asset('public/website-assets/js/jquery.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('public/website-assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
    <?php echo $__env->yieldContent('header'); ?>
   
    <?php echo $__env->make('website.blocks.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="body-cls">
<input type="hidden" id="base_path" value="<?php echo e(url('/')); ?>/"/>
<input type="hidden" id="abs_path" value="<?php echo e(base_path('')); ?>"/>
<script src="<?php echo e(asset('public/website-assets/js/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/website-assets/js/legacy.js')); ?>" type="text/javascript"></script>
<?php if(\Request::segment(1) == 'calculators'): ?>
    <script src="<?php echo e(asset('public/website-assets/js/calculators/modules.js')); ?>" type="text/javascript"></script>
<?php endif; ?>
<script type="text/javascript">
    var javascript_site_path = '<?php echo e(url('/')); ?>';
    var web_local = '<?php echo e(config('app.locale')); ?>';
</script>

<?php echo $__env->yieldContent('content'); ?>

<?php if(\Request::segment(2) != "user"): ?>
    <?php echo $__env->make('website.regions.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<!---------------------------------- JS Files Link ---------------------------------->


<script src="<?php echo e(asset('public/website-assets/js/jquery.mCustomScrollbar.concat.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('public/website-assets/js/wow.js')); ?>" type="text/javascript"></script>





<script src="<?php echo e(asset('public/website-assets/js/owl.carousel.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('public/website-assets/js/custom.js')); ?>" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo e(url('public/website-assets/js/jquery.validate.js')); ?>"></script>
<script src="<?php echo e(asset('public/website-assets/js/validation.js')); ?>" type="text/javascript"></script>

<script>
    new WOW().init();
</script>

<?php echo $__env->yieldContent('footer'); ?>
</body>
</html>
