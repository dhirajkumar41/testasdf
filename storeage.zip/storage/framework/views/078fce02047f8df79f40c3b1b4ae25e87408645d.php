<?php $__env->startSection('page_title'); ?>
    Fiscalia
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.regions.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="inner-page-sec">
        <div class="container">
            <div class="special-sec inst">
                <div class="row" style="height: 200px">
                    <span style="margin:auto;font-size: 30px;color: #00b176">Welcome to Fiscalia </span>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>