<footer>
    <div class="subscript-sec">
        <div class="container">
            <div class="subscription">
                <div class="row">
                    <div class="col-md-6">
                        <div class="subscript-in">
                            <div class="subscript-bg">
                                <div class="subscrpt-txt">
                                    <h3><?php echo e(trans('footer.new_to_fiscalia')); ?></h3>
                                    <p><?php echo e(trans('footer.subscribe_today')); ?></p>
                                </div>
                                <div class="subscript-btn">
                                    <button type="button"><?php echo e(trans('footer.subscribe')); ?></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="subscript-in">
                            <div class="subscript-bg">
                                <div class="subscrpt-txt">
                                    <h3><?php echo e(trans('footer.are_you_fiscalia_member')); ?></h3>
                                    <p><?php echo e(trans('footer.click_here_to_login')); ?></p>
                                </div>
                                <div class="subscript-btn">
                                    <button type="button"><?php echo e(trans('footer.log_in')); ?></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <div class="container">
            <div class="footer-in">
                <div class="row">
                    <div class="footer-main-logo">
                        <div class="col-md-12">
                            <img src="<?php echo e(url('/')); ?>/public/website-assets/images/logo_white.png" alt="image">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 col-xs-6">
                        <div class="footer-info">
                            <div class="footer-head">
                                <h4><?php echo e(trans('footer.content')); ?></h4>
                            </div>
                            <div class="footer-link">
                                <ul>
                                    <li><a href="javascript:void(0);"><?php echo e(trans('footer.publications')); ?> </a></li>
                                    <li><a href="javascript:void(0);"><?php echo e(trans('footer.legislation')); ?> </a></li>
                                    <li><a href="javascript:void(0);"><?php echo e(trans('footer.indicators')); ?> </a></li>
                                    <li><a href="javascript:void(0);"> <?php echo e(trans('footer.tesis')); ?> </a></li>
                                    <li><a href="javascript:void(0);"> <?php echo e(trans('footer.calculators')); ?>  </a></li>
                                    <li><a href="javascript:void(0);"><?php echo e(trans('footer.dof')); ?> </a></li>
                                    <li><a href="javascript:void(0);"><?php echo e(trans('footer.tools')); ?></a></li>
                                    <li><a href="javascript:void(0);"><?php echo e(trans('footer.community')); ?></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="footer-info">
                            <div class="footer-head">
                                <h4>ENLACES</h4>
                            </div>
                            <div class="footer-link">
                                <ul>
                                    <li><a href="javascript:void(0);"><?php echo e(trans('footer.contact')); ?> </a></li>
                                    <li><a href="javascript:void(0);"><?php echo e(trans('footer.about_fiscalia')); ?></a></li>
                                    <li><a href="javascript:void(0);"><?php echo e(trans('footer.invite_friend')); ?></a></li>
                                    <li><a href="javascript:void(0);"><?php echo e(trans('footer.subscribe')); ?></a></li>
                                    <li><a href="javascript:void(0);"><?php echo e(trans('footer.fiscalia_on_your_site')); ?></a></li>
                                    <li><a href="javascript:void(0);"><?php echo e(trans('footer.work_in_fiscalia')); ?> </a></li>
                                    <li><a href="javascript:void(0);"><?php echo e(trans('footer.your_homepage')); ?></a></li>
                                    <li><a href="javascript:void(0);"><?php echo e(trans('footer.publish_your_articles')); ?></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="footer-info">
                            <div class="footer-head">
                                <h4><?php echo e(trans('footer.contact_us')); ?></h4>
                            </div>
                            <div class="footer-cont-info">
                                <p><span class="foot-icon-txt"> 01 800 467-0956</span></p>
                                <p><span class="foot-icon-txt map-l"> contacto@fisc­alia.com</span></p>
                            </div>
                            <div class="foter-cont-logo">
                                <img src="<?php echo e(url('/')); ?>/public/website-assets/images/prueba-fiscalia.png" alt="image" class="img-responsive">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-xs-6">
                        <div class="footer-info">
                            <div class="footer-head">
                                <h4><?php echo e(trans('footer.group_sites')); ?></h4>
                            </div>
                            <div class="footer-logo">
                                <img src="<?php echo e(url('/')); ?>/public/website-assets/images/lb_logo_color.png" alt="image">
                                <img src="<?php echo e(url('/')); ?>/public/website-assets/images/mis_impuestos_logo_color.png" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-sec">
        <div class="container">
            <div class="copyright">
                <div class="left-sec">
                    <a href="javascript:void(0);" target="_blank">
                        <?php echo e(trans('footer.terms_notice')); ?>

                    </a>
                </div>
                <div class="right-sec">
                    <a href="javascript:void(0);" target="_blank">
                        © <?php echo e(trans('footer.all_rights_reserved')); ?> MMI - MMXVIII
                    </a>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function(){
            $("#btn_cust_dropdown").click(function(){
                $(".slide-dropdown").slideToggle();
            });
            $("#btn_cust_dropdown-filter").click(function(e) {
//            $(this).find('[class=slide-dropdown-filter]').slideToggle();
                 $(".slide-dropdown-filter").slideToggle();
            });
            $("#btn_cust_dropdown_sort_by").click(function(e) {
                $('.slide_dropdown_sort_by').slideToggle();
                //            $(".slide-dropdown-filter").slideToggle();
            });
        });
    </script>
</footer>