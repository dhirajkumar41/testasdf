<header id="main_header" class="my-header">
    <div class="custom-header">
        <div class="logo">
            <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/public/website-assets/images/logo_white.png')); ?>" alt="image"></a>
        </div>
        <div class="header-right">
            <div class="search-b hidden-sm hidden-xs">
                <form>
                    <div id="search-wrapper" class="form-group">
                        <input class="form-control sear-in" type="search" placeholder="<?php echo e(trans('header.search')); ?>" name="q">
                        <span><i class="fa fa-search"></i></span>
                    </div>
                </form>
            </div>
            <div class="top-link">
                <ul class=" hidden-sm  hidden-xs text-right">
                    <?php if((\Illuminate\Support\Facades\Auth::guest())): ?>
                    <li><a style="cursor: pointer" class="btn btn-link text-uppercase" href="<?php echo e(url('/subscriptions')); ?>"><?php echo e(trans('header.Subscribe')); ?></a></li>
                        <li><a style="cursor: pointer" class="btn btn-link text-uppercase" href="<?php echo e(url('/login')); ?>"><?php echo e(trans('header.Log_in')); ?></a></li>
                    <?php else: ?>
                      <li>
                        <div class="cust-dropdown">
                            <button id="btn_cust_dropdown"><?php echo e(\Illuminate\Support\Facades\Auth::user()->username); ?></button>
                            <div class="slide-dropdown">
                                <ul>
                                    <li><a href="<?php echo e(url('/subscriptions-plan')); ?>"><?php echo e(trans('header.account')); ?></a></li>
                                    <li><a href="<?php echo e(url('/favorites')); ?>"><?php echo e(trans('header.my_favorites')); ?></a></li>
                                    <li><a href="<?php echo e(url('/chat')); ?>"><?php echo e(trans('header.delivery_courier')); ?></a></li>
                                    <li><a href="<?php echo e(url('/logout')); ?>"><?php echo e(trans('header.sign_off')); ?></a></li>
                                </ul>
                            </div>
                        </div>
                      </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="main-header">
        <div class="hamberger"><span class="lines"></span></div>
        <div class="my-menu">
            <ul>
                <li class="hidden-lg hidden-md"><a class="btn btn-link" href="<?php echo e(url('/subscriptions')); ?>"><?php echo e(trans('header.Subscribe')); ?></a></li>
                <li class="hidden-lg hidden-md"><a class="btn btn-link " href="<?php echo e(url('/login')); ?>"><?php echo e(trans('header.Log_in')); ?></a></li>
                <li><a href="javascript:void(0);"><?php echo e(trans('header.Publications')); ?></a></li>
                <li><a href="<?php echo e(url('/lagislations')); ?>"><?php echo e(trans('header.Legislation')); ?></a></li>
                <li><a href="<?php echo e(url('/indicators')); ?>"><?php echo e(trans('header.Indicators')); ?></a></li>
                <li><a href="<?php echo e(url('/tesis')); ?>"><?php echo e(trans('header.Tesis')); ?></a></li>
                <li><a href="<?php echo e(url('/calculators')); ?>"><?php echo e(trans('header.Calculators')); ?></a></li>
                <li><a href="<?php echo e(url('/dof')); ?>"><?php echo e(trans('header.DOF')); ?></a></li>
                <li><a href="javascript:void(0);"><?php echo e(trans('header.Tools')); ?></a></li>
                <li><a href="javascript:void(0);"><?php echo e(trans('header.Community')); ?></a></li>
                <li><a href="javascript:void(0);"><?php echo e(trans('header.courses')); ?></a></li>
            </ul>
        </div>
    </div>
</header>
