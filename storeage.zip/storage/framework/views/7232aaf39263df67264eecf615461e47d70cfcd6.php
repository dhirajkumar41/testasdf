<?php $__env->startSection('page_title'); ?>
Log In
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('website.regions.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('website.regions.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="well login-box ">
    <legend>Log In</legend>
    
    <form action="<?php echo e(action('WebsiteController@postLogin')); ?>" method="POST">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="form-group clearfix">
            <label for="username-email">Email Id</label>
            <input type="text" id="username-email" name="user_email" class="form-control <?php if($errors->has('user_email')): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('username')); ?>" />
            <p class="help-block">ex. abc@example.com</p>
            <?php if($errors->has('user_email')): ?>
                <span class="help-block">
                    <strong class="text-danger"><?php echo e($errors->first('user_email')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group clearfix">
            <label for="password">Password</label>
            <input type="password" id="password" name="user_password" class="form-control" />
            <?php if($errors->has('user_password')): ?>
                <span class="help-block">
                    <strong class="text-danger"><?php echo e($errors->first('user_password')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group text-center">
            
            <button type="submit" class="btn btn-success btn-login-submit">Login</button>

            <a href="<?php echo e(url('/register')); ?>" class="btn btn-danger btn-cancel-action">Register</a>
            <span class="forgot-pass"><a href="<?php echo e(url('/forgot-password')); ?>">Forgot Password</a></span>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>