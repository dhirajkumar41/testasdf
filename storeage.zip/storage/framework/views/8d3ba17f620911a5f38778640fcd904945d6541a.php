<html>
<head>
    <title>
        Denied
    </title>
    <style type="text/css">
        html, body {
            height: 100%;
        }

        body {
            margin: 0;
            padding: 0;
            width: 100%;
            color: #B0BEC5;
            display: table;
            font-weight: 100;
            font-family: 'Lato', sans-serif;
        }

        .container {
            text-align: center;
            display: table-cell;
            vertical-align: middle;
        }

        .content {
            text-align: center;
            display: inline-block;
        }

        .title {
            font-size: 72px;
            margin-bottom: 40px;
        }
        /*.error-template {padding: 40px 15px;text-align: center;}*/
        /*.error-actions {margin-top:15px;margin-bottom:15px;}*/
        /*.error-actions .btn { margin-right:10px; }*/
    </style>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="error-template">
                <h1>
                    Oops!</h1>
                <h2>
                    404 Not Found</h2>
                <div class="error-details">
                    Sorry, an error has occured, Requested page not found!
                </div>
                
                    
                    
                
            </div>
        </div>
    </div>
</div>
</body>
</html>
