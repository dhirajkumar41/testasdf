<section class="icon-text-sec">
    <div class="container">
        <div class="icon-txt-sec-in">
            <div class="row">
                <div class="inner-icon-txt">
                    <div class="col-md-4 col-xs-4">
                        <div class="in-icon-info">
                            <a href="javascript:void(0);">
                                <div class="icon-img">
                                    <img src="<?php echo e(asset('/public/website-assets/images/thumb_121.png')); ?>" alt="img">
                                    <span class="i-txt">CFDI 3.3</span>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-4">
                        <div class="in-icon-info">
                            <a href="javascript:void(0);">
                                <div class="icon-img">
                                    <img src="<?php echo e(asset('/public/website-assets/images/thumb_109.png')); ?>" alt="img">
                                    <span class="i-txt">Contabilidad electrónica</span>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-4">
                        <div class="in-icon-info">
                            <a href="javascript:void(0);">
                                <div class="icon-img">
                                    <img src="<?php echo e(asset('/public/website-assets/images/thumb_141.png')); ?>" alt="img">
                                    <span class="i-txt">PTU 2018</span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="advertise-img">
                        <img src="<?php echo e(asset('/public/website-assets/images/unnamed.png')); ?>" alt="image">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>